import 'package:flutter/material.dart';
import '../db/notes_database.dart';
import '../models/note.dart';

class NoteProvider extends ChangeNotifier {
  List<Note> _notes = [];
  String _searchQuery = '';
  bool _isDarkMode = false;

  List<Note> get notes => _notes;
  String get searchQuery => _searchQuery;
  bool get isDarkMode => _isDarkMode;

  List<Note> get filteredNotes {
    if (_searchQuery.isEmpty) return _notes;
    return _notes
        .where(
          (note) =>
              note.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
              note.content.toLowerCase().contains(_searchQuery.toLowerCase()),
        )
        .toList();
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  void toggleTheme() {
    _isDarkMode = !_isDarkMode;
    notifyListeners();
  }

  Future loadNotes() async {
    _notes = await NotesDatabase.getNotes();
    notifyListeners();
  }

  Future addNote(Note note) async {
    await NotesDatabase.addNote(note);
    await loadNotes();
  }

  Future updateNote(Note note) async {
    await NotesDatabase.updateNote(note);
    await loadNotes();
  }

  Future deleteNote(int id) async {
    await NotesDatabase.deleteNote(id);
    await loadNotes();
  }
}
